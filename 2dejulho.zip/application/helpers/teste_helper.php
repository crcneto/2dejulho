<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function teste($var){
    echo "<pre>";
    print_r($var);
    echo "</pre>";
    die();
}

