<div class="container-fluid">
    <div class="panel panel-primary">
        <div class="panel-heading">
            <div class="panel-title text-center"></div>
        </div>
        <div class="panel-body">
            
        </div>
    </div>
</div>
